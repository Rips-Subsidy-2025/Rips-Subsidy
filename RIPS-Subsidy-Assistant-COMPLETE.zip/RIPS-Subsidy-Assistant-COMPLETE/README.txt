Deploy this folder on Streamlit Cloud. Main file: app/app.py
